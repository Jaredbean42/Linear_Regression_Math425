# Statistics-Notebook
This began as the textbook for Intermediate Statistics (Math 325) at BYU-Idaho. It aims to become a personal notebook for performing and interpreting statistical analyses in R.
